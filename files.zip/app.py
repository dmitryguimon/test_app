from flask import Flask, render_template, request, redirect, url_for
from models import init_db, get_all_comments, add_comment

app = Flask(__name__)

@app.before_first_request
def initialize():
    init_db()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        author = request.form.get("author")
        content = request.form.get("content")
        parent_id = request.form.get("parent_id")
        add_comment(author, content, parent_id)
        return redirect(url_for("index"))
    comments = get_all_comments()
    return render_template("index.html", comments=comments)

if __name__ == "__main__":
    app.run(debug=True)