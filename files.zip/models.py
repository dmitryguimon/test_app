import sqlite3

DB = "comments.db"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            author TEXT NOT NULL,
            content TEXT NOT NULL,
            parent_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(parent_id) REFERENCES comments(id)
        )
    ''')
    conn.commit()
    conn.close()

def add_comment(author, content, parent_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute(
        "INSERT INTO comments (author, content, parent_id) VALUES (?, ?, ?)",
        (author, content, parent_id if parent_id else None)
    )
    conn.commit()
    conn.close()

def get_all_comments():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT id, author, content, parent_id, created_at FROM comments ORDER BY created_at ASC")
    comments = c.fetchall()
    conn.close()
    # Convert to nested structure
    comment_dict = {}
    for id, author, content, parent_id, created_at in comments:
        comment = {
            "id": id,
            "author": author,
            "content": content,
            "parent_id": parent_id,
            "created_at": created_at,
            "children": []
        }
        comment_dict[id] = comment
    root_comments = []
    for comment in comment_dict.values():
        if comment["parent_id"]:
            comment_dict[comment["parent_id"]]["children"].append(comment)
        else:
            root_comments.append(comment)
    return root_comments